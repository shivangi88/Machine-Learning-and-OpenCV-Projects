"""
@author: shivangi
The following code has been referred from the links given below:-
https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_ml/py_kmeans/py_kmeans_opencv/py_kmeans_opencv.html
http://scikit-learn.org/stable/auto_examples/cluster/plot_color_quantization.html

"""
UBIT = 'shivangi'; 
import numpy as np; 
np.random.seed(sum([ord(c) for c in UBIT]))

import matplotlib.pyplot as plt
#import copy
import numpy as np
import cv2

f1=[5.9, 4.6, 6.2,4.7,5.5,5.0,4.9,6.7,5.1,6.0]
f2=[3.2,2.9,2.8,3.2,4.2,3.0,3.1,3.1,3.8,3.0]
classification_vector=[]
# Getting the data points
X = np.array(list(zip(f1, f2)))
# Euclidean Distance Caculator
def dist(a, b, ax=1):
    k=[]
    for i in range(len(a)):
        k.append(np.linalg.norm(a[i] - b, axis=ax))
    return k
def minCluster(a):
    k=[]
    for i in range(len(a)):
        k.append(np.argmin(a[i]))
    return k
# Number of clusters
k = 3
# X coordinates of given centroids
C_x = [6.2,6.6,6.5]
# Y coordinates of given centroids
C_y = [3.2,3.7,3.0]
# Getting the centroids
C = np.array(list(zip(C_x, C_y)), dtype=np.float32)
# Storing the value of centroids when they gets updated
C_old = np.zeros(C.shape)
# Cluster Lables(0, 1, 2)
clusters = np.zeros(len(X))
# Error functionwhich is calculated asd istance between new centroids and old centroids
#error = dist(C, C_old, None)
# Loop will runs till the error becomes zero 
temp=0  #Checking condition for producing output every iteration
colors = ['r', 'g', 'b']
fig, ax = plt.subplots()
def kMeansClusteringAlgo(X,iteration,temp,k,isImage=0):
	clusters=[]
	while iteration != 0:
		temp=temp+1
		for i in range(len(X)):
			distances = dist(X[i], C)
			cluster = minCluster(distances)
			for k in range(len(cluster)):
				clusters.append(cluster)
		#for i in range(len(C)):
			#C_old = copy.deepcopy(C)
		# Finding the new centroids by taking the average value
		for i in range(k):
			points = [X[j] for j in range(len(X)) if clusters[j] == i]
			C[i] = np.mean(points, axis=0)
		iteration =iteration-1
	return C,clusters
#centres,clust=kMeansClusteringAlgo(X,2,temp,3)

img = cv2.imread('baboon.jpg')
Z = img.reshape((-1,3))

# convert to np.float32
Z = np.float32(Z)
w,h=Z.shape
temp=0 
# define criteria, number of clusters(K) and apply kmeans()
K = 3
center,clust=kMeansClusteringAlgo(Z,5,temp,K,isImage=1)

# Now convert back into uint8, and make original image
center = np.uint8(center)
#res = center.fit(clust)
#res2 = res.reshape((img.shape))
def recreate_image(codebook, labels, w, h):
    d = codebook.shape[1]
    image = np.zeros((w, h, d))
    #label_idx = 0
    for i in range(w):
        for j in range(h):
            image[i][j] = codebook[labels[i][j]]
            #label_idx += 1
    return image
res2=recreate_image(center, clust, w, h)
res2 = res2.astype('uint8')
cv2.imwrite('res2.jpg',res2)
cv2.waitKey(0)
cv2.destroyAllWindows()

